from flask import Flask, request, jsonify, send_from_directory
from pathlib import Path
import subprocess, sys, uuid, os

BASE = Path(__file__).resolve().parent
ENGINE = BASE / "engine"
MAIN = ENGINE / "main.py"
app = Flask(__name__)

@app.get("/")
def home():
    return send_from_directory(BASE / "public", "index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "engine_ready": MAIN.exists()})

@app.post("/api/obfuscate")
def obfuscate():
    data = request.get_json(silent=True) or {}
    code = data.get("code")
    mode = data.get("mode", "lightweight")
    if not isinstance(code, str) or not code.strip():
        return jsonify(error="أدخل كود Luau أولاً."), 400
    if len(code.encode("utf-8")) > 200_000:
        return jsonify(error="حجم الكود يتجاوز 200KB."), 413
    if mode not in ("lightweight", "rename", "native", "vm"):
        return jsonify(error="مستوى الحماية غير صالح."), 400
    if not MAIN.exists():
        return jsonify(error="محرك Luau غير مثبت على الخادم."), 503

    work = ENGINE / ".vault_jobs"
    work.mkdir(exist_ok=True)
    token = uuid.uuid4().hex
    source, output = work / f"{token}.luau", work / f"{token}.obf.luau"
    try:
        source.write_text(code, encoding="utf-8")
        run = subprocess.run(
            [sys.executable, str(MAIN), str(source), "--mode", mode, "-o", str(output)],
            cwd=ENGINE, capture_output=True, text=True, timeout=90
        )
        if run.returncode != 0 or not output.exists():
            return jsonify(error=(run.stderr or run.stdout or "فشل المحرك.")[-2500:]), 422
        return jsonify(output=output.read_text(encoding="utf-8"),
                       mode=mode,
                       message="اكتملت المعالجة. اختبر الناتج في Roblox Studio.")
    except subprocess.TimeoutExpired:
        return jsonify(error="انتهت مهلة المعالجة بعد 90 ثانية."), 408
    finally:
        source.unlink(missing_ok=True)
        output.unlink(missing_ok=True)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "4173")))
